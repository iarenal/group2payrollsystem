/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.table.DefaultTableModel;

public class Finance extends Timesheet {
    protected String SSSno, Pagibigno, Philhealthno, TIN, basicSalary, clothingAllowance,
            phoneAllowance, riceSubsidy;
                
    public void setSSSno(String sss){
       SSSno = sss;
    }
    
    public String getSSSno(){
       return SSSno;
    }
    public void setPagibigno(String pagibig){
       Pagibigno = pagibig;
    }
    
    public String getPagibigno(){
       return Pagibigno;
    }
    public void setPhilhealthno(String philh){
       Philhealthno = philh;
    }
    
    public String getPhilhealthno(){
       return Philhealthno;
    }
    public void setTIN(String tin){
       TIN = tin;
    }
    
    public String getTIN(){
       return TIN;
    }
    

    public void setBasicSalary(String bs){
       basicSalary = bs;
    }
    
    public String getBasicSalary(){
       return basicSalary;
    }
         
        public String getClothing(){
       return clothingAllowance;
   }
       public void setClothing(String ca){
       clothingAllowance = ca;
   }
       public String getPhone(){
       return phoneAllowance;
   }
       public void setPhone(String pa){
       phoneAllowance = pa;
   }
      public String getRice(){
       return riceSubsidy;
   }
      public void setRice(String rs){
       riceSubsidy = rs;
   }
      public DefaultTableModel ViewPayrollData () throws IOException, CsvValidationException {
        String CSVEmployee = "PayrollData.csv";
        DefaultTableModel Information;
        try(CSVReader Reader = new CSVReader(new FileReader(CSVEmployee))){
            String[] Data = Reader.readNext();
            Information = new DefaultTableModel(Data,0);
            String[] line;
            while((line = Reader.readNext()) != null){
                Information.addRow(line);
            }
        }
        return Information;
       }
      
         public DefaultTableModel searchtblpayroll() throws FileNotFoundException, IOException, CsvValidationException {
        DefaultTableModel PayDetails;
         String CSVFilename = "PayrollData.csv";
        try (CSVReader reader = new CSVReader(new FileReader(CSVFilename))) {
            String[] information = reader.readNext();
            PayDetails = new DefaultTableModel(information, 0);

            String[] column;
            while ((column = reader.readNext()) != null) {
                if (column[0].equals(EmployeeID)|column[1].equals(lastName)) {
                    PayDetails.addRow(column);
                }
            }
        }

        return PayDetails;
    }
      
      public void SearchPayroll()throws IOException, CsvValidationException{
        String CSVFilename = "PayrollData.csv";
        try(CSVReader Reader = new CSVReader(new FileReader(CSVFilename))){
            String[] Details;
            while((Details = Reader.readNext()) != null){
                if (Details[1].equals(lastName) || Details[0].equals(EmployeeID)){
                     EmployeeID = Details[0];
                     lastName = Details[1];           
                     SSSno  = Details[4];
                     Philhealthno = Details[5];
                     TIN = Details[6];
                     Pagibigno = Details[7];
                     riceSubsidy = Details[8];
                     phoneAllowance = Details[9];
                     clothingAllowance = Details[10];
                     basicSalary = Details[11];
                }
            }
        }
    }
}


