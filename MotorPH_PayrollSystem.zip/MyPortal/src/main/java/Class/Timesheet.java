/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvValidationException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.table.DefaultTableModel;

public class Timesheet extends Employee{
    protected String date, TimeIn, TimeOut, WrkdHrs,Overtime, payPeriod;
    protected double Twrkd, Tot;

    public void setPayPeriod (String payP){
       payPeriod = payP;
    }
    
    public String getcurrentPayPeriod(){
        Date current = new Date();
        String dateformat = "MM-yyyy";
        SimpleDateFormat formatter = new SimpleDateFormat(dateformat);
        String PayPeriod = formatter.format(current);
       return PayPeriod;
    }
    
     public String getPayPeriod(){
       return payPeriod;
   }
    
   public String getcurrentDate (){
        Date current = new Date();
        String dateformat = "MM-dd-yyyy";
        SimpleDateFormat formatter = new SimpleDateFormat(dateformat);
        String Date = formatter.format(current);
        return Date;
    }
  
   public String getDate(){
       return date;
   }
      
    public void setDate (String d){
        date = d;
    }  
    
        public String getTime (){
        Date current = new Date();
        String timeformat = "HH:mm";
        SimpleDateFormat formatter = new SimpleDateFormat(timeformat);
        String Time = formatter.format(current);
        return Time;
    }
    
        public void setTimeIn(String In){
        TimeIn = In;
    }
    public String getTimeIn(){
        return TimeIn;
    }
    public void setTimeOut(String Out){
        TimeOut = Out;
    }    
    public String getTimeOut(){
        return TimeOut;
    }
    public void setHrs(String hrs) {
          WrkdHrs = hrs;
    } 
    
    public String getHrs(){
        return WrkdHrs;
    }
    public String calculateDailyHrs() throws ParseException{
        SimpleDateFormat format = new SimpleDateFormat("HH:mm");
            Date In = format.parse(TimeIn);
            Date Out = format.parse(TimeOut);         
       WrkdHrs = String.valueOf((Out.getTime() - In.getTime())/3600000);
         return WrkdHrs;  
    }    
    
     public void setOT(String ot) {
          Overtime = ot;
    }  
    public String getOT() {
         return Overtime;
    } 
    
    public String calculateDailyOT(){
       if((0 > Integer.parseInt(WrkdHrs) - 8)){
           Overtime = "0";
       }
       else{
           Overtime = String.valueOf(Integer.parseInt(WrkdHrs) - 8);
       }
       return Overtime;
    }
    
    public void setTHrs(Double Thrs) {
          Twrkd = Thrs;
    }  
    public String getTHrs() {
         return String.valueOf(Twrkd);
    } 
    
    public void setTOvetime(Double TO) {
          Tot = TO;
    }  
    public String getTOvertime() {
         return String.valueOf(Tot);
    } 
    
    public DefaultTableModel viewMTSRecord() throws FileNotFoundException, IOException, CsvValidationException {
        DefaultTableModel timesheet;
        String CSVFilename = "Timesheet.csv";

        try (CSVReader reader = new CSVReader(new FileReader(CSVFilename))) {
            String[] information = reader.readNext();
            timesheet = new DefaultTableModel(information, 0);

            String[] column;
            while ((column = reader.readNext()) != null) {
                if ((column[0].equals(EmployeeID) && column[2].equals(payPeriod))) {
                    timesheet.addRow(column);
                    Twrkd += Integer.parseInt(column[6]);
                    Tot += Integer.parseInt(column[5]);
                }
            }
        }

        return timesheet;
    }
        public DefaultTableModel viewTSRecord() throws FileNotFoundException, IOException, CsvValidationException {
        DefaultTableModel timesheet;
        String CSVFilename = "Timesheet.csv";

        try (CSVReader reader = new CSVReader(new FileReader(CSVFilename))) {
            String[] information = reader.readNext();
            timesheet = new DefaultTableModel(information, 0);

            String[] column;
            while ((column = reader.readNext()) != null) {
                if (column[0].equals(EmployeeID)) {
                    timesheet.addRow(column);
                }
            }
        }

        return timesheet;
    }
     
    public void AddTimeIn() throws IOException{
        String CSVPayperiod = "Timesheet.csv";
        try(CSVWriter Writer = new CSVWriter(new FileWriter(CSVPayperiod, true))){
         String [] Information = new String [7];   
            Information[0] = EmployeeID;
            Information[1] = date;
            Information[2] = payPeriod;
            Information[3] = TimeIn;
            Information[5] = "0";
            Information[6] = "0";         
           Writer.writeNext(Information);
        }    
    } 
     
        public void AddTimeOut() throws FileNotFoundException, IOException, CsvValidationException{
        String CSVFilename = "Timesheet.csv";
        String temporaryfile = CSVFilename.replace(".csv", ".tmp"); 
        CSVReader Reader = new CSVReader (new FileReader(CSVFilename)); 
        String[] Column;
        try(CSVWriter Writer = new CSVWriter(new FileWriter(temporaryfile, true))) {
            while((Column = Reader.readNext()) != null){
                if (Column[0].equals(EmployeeID)&&Column[1].equals(date)){
                    Column[0] = EmployeeID;
                    Column[1] = date;
                    Column[2] = payPeriod;
                    Column[3] = TimeIn;
                    Column[4] = TimeOut;
                    Column[5] = Overtime;
                    Column[6] = WrkdHrs;
                }
                Writer.writeNext(Column); 
            }
            Reader.close();
        }
        new File(CSVFilename).delete();
        new File(temporaryfile).renameTo(new File(CSVFilename));
        }
    
                
        public void SearchTS()throws IOException, CsvValidationException{
        String CSVFilename = "Timesheet.csv";
        try(CSVReader Reader = new CSVReader(new FileReader(CSVFilename))){
            String[] Details;
            while((Details = Reader.readNext()) != null){
                if (Details[1].equals(date)&&Details[0].equals(EmployeeID)){
                     EmployeeID = Details[0];
                     date = Details[1];
                     payPeriod = Details[2];
                     TimeIn = Details[3];   
                     TimeOut = Details[4];
                     Overtime = Details[5];
                     WrkdHrs = Details[6];
                }
            }
        }
    }
        public boolean checkrecord() throws FileNotFoundException, IOException, CsvValidationException{
            String csvFilename = "Timesheet.csv";
               try(CSVReader reader = new CSVReader(new FileReader(csvFilename))){
            String[] Information;
           while((Information = reader.readNext()) != null){
              if(Information[0].equals(EmployeeID) && Information[2].equals(payPeriod)){
                return Information[1].equals(date);
              }
            }
        }
      return false;        
    }
      public String calculateTwrkdH () throws IOException, CsvValidationException{
        String CSVEmployee = "Timesheet.csv";
        try(CSVReader Reader = new CSVReader(new FileReader(CSVEmployee))){
            String[] Column;
            while((Column = Reader.readNext()) != null){
                if ((Column[0].equals(EmployeeID) && Column[2].equals(payPeriod))) {
                    Twrkd += Integer.parseInt(Column[6]);
                }
            }
        }
        return String.valueOf(Twrkd);
     }
      public String calculateTOT () throws IOException, CsvValidationException{
        String CSVEmployee = "Timesheet.csv";
        try(CSVReader Reader = new CSVReader(new FileReader(CSVEmployee))){
            String[] Column;
            while((Column = Reader.readNext()) != null){
                if ((Column[0].equals(EmployeeID) && Column[2].equals(payPeriod))) {
                    Tot += Integer.parseInt(Column[5]);
                }
            }
        }
        return String.valueOf(Tot);
     }
}

     
