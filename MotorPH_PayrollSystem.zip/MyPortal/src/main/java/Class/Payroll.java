/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvValidationException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Yssha
 */

 class Earnings extends Finance{
     protected double rate, overtimePay, mRate, grossPay;
     
    public void setrate(Double r){
       rate = r;
    }
        
    public String calculateRate(){
        rate = (Double.parseDouble(basicSalary)/21)/8;
        return String.format("%.2f", rate);
    }
    
    public void setOvertimePay(Double OT){
            overtimePay = OT;
    }
    
    public String calculateOvertimePay(){
        overtimePay = rate * 1.25 * Tot;
        return String.format("%.2f", overtimePay);
    }
    
   public void setMonthlyRate(Double mR){
            mRate = mR;
    }
    
    public String calculateMonthlyRate(){
        mRate = (rate * (Twrkd - Tot));
        return String.format("%.2f", mRate);
    } 
    
    public void setGrossPay(Double GP){
            grossPay = GP;
    }
    
    public String calculateGrossPay(){
        grossPay = mRate + overtimePay;
        return String.format("%.2f", grossPay);
    }    
 }

 class Benefits extends Earnings{
    protected double totalAllowance;
    
    public void setTotalAllowance(Double TA){
            totalAllowance = TA;
    }
    
    public String calculateTotalAllowance(){
        totalAllowance = Double.parseDouble(clothingAllowance) + Double.parseDouble(phoneAllowance) + Double.parseDouble(riceSubsidy);
        return String.format("%.2f", totalAllowance);
    }
 }
 
 class Deduction extends Benefits{   
    private double SSS, Pagibig, Philhealth, taxableIncome, withholdingTax;
    protected double totalDeductions;
    
    public String calculateSSS(){ // computes for  SSS
        
        if (Double.parseDouble(basicSalary) <= 3250)
         { SSS = 135;}
      
        else if (Double.parseDouble(basicSalary) <= 3750)
         { SSS = 157.50;}  
       
       else if (Double.parseDouble(basicSalary) <= 4250)
         { SSS =  180.00;}  

       else if (Double.parseDouble(basicSalary) <= 4750)
         { SSS = 202.50;}  
       
        else if (Double.parseDouble(basicSalary) <= 5250)
         { SSS = 225.00;}  
       
        else if (Double.parseDouble(basicSalary) <= 5750)
         { SSS = 247.50;}  
       
        else if (Double.parseDouble(basicSalary) <= 6250)
         { SSS = 270;}  
        
        else if (Double.parseDouble(basicSalary) <= 6750)
         { SSS = 292.50;}  
       
        else if (Double.parseDouble(basicSalary) <= 7250)
         { SSS = 337.50;}  
        
        else if (Double.parseDouble(basicSalary) <= 7750)
         { SSS = 337.50;}  
        
        else if (Double.parseDouble(basicSalary) <= 8250)
         { SSS = 360.00;}  
        
        else if (Double.parseDouble(basicSalary) <= 8750)
         { SSS = 382.50;}
        
        else if (Double.parseDouble(basicSalary) <= 9250)
         { SSS = 405.00;}
        
        else if (Double.parseDouble(basicSalary) <= 9750)
         { SSS = 427.50;}
        
        else if (Double.parseDouble(basicSalary) <= 10250)
         { SSS = 450.00;}
        
        else if (Double.parseDouble(basicSalary) <= 10750)
         { SSS = 472.50;}
        
        else if (Double.parseDouble(basicSalary) <= 11250)
         { SSS = 495.00;}
        
        else if (Double.parseDouble(basicSalary) <= 11750)
         { SSS = 517.50;}
        
        else if (Double.parseDouble(basicSalary) <= 12250)
         { SSS = 540.00;}
        
        else if (Double.parseDouble(basicSalary) <= 12750)
         { SSS = 562.50;}
        
        else if (Double.parseDouble(basicSalary) <= 13250)
         { SSS = 585.00;}
        
        else if (Double.parseDouble(basicSalary) <= 13750)
         { SSS = 607.50;}
        
        else if (Double.parseDouble(basicSalary) <= 14250)
         { SSS = 630.00;}
        
        else if (Double.parseDouble(basicSalary) <= 14750)
         { SSS = 652.50;}
        
        else if (Double.parseDouble(basicSalary) <= 15250)
         { SSS = 675.00;}
        
        else if (Double.parseDouble(basicSalary) <= 15750)
         { SSS = 697.50;}
        
        else if (Double.parseDouble(basicSalary) <= 16250)
         { SSS = 720.00;}
        
        else if (Double.parseDouble(basicSalary) <= 16750)
         { SSS = 742.50;}
        
        else if (Double.parseDouble(basicSalary) <= 17250)
         { SSS = 765.00;}
        
        else if (Double.parseDouble(basicSalary) <= 17750)
         { SSS = 787.50;}
        
        else if (Double.parseDouble(basicSalary) <= 18250)
         { SSS = 810.00;}
        
        else if (Double.parseDouble(basicSalary) <= 18750)
         { SSS = 832.50;}
        
        else if (Double.parseDouble(basicSalary) <= 19250)
         { SSS = 855.00;}
        
        else if (Double.parseDouble(basicSalary) <= 19750)
         { SSS = 877.50;}
        
        else if (Double.parseDouble(basicSalary) <= 20250)
         { SSS = 900.00;}
        
        else if (Double.parseDouble(basicSalary) <= 20750)
         { SSS = 922.50;}
        
        else if (Double.parseDouble(basicSalary) <= 21250)
         { SSS = 945.00;}
        
        else if (Double.parseDouble(basicSalary) <= 21750)
         { SSS = 967.50;}
        
        else if (Double.parseDouble(basicSalary) <= 22250)
         { SSS = 990.00;}
        
        else if (Double.parseDouble(basicSalary) <= 22750)
         { SSS = 1012.50;}
        
        else if (Double.parseDouble(basicSalary) <= 23250)
         { SSS = 1035.00;}
        
        else if (Double.parseDouble(basicSalary) <= 23750)
         { SSS = 1057.50;}
         
        else if (Double.parseDouble(basicSalary) <= 24250)
         { SSS = 1080.00;}
        
        else if (Double.parseDouble(basicSalary) <= 24750)
         { SSS = 1102.50;}
        
        else 
         { SSS = 1125.00;}
        
        return String.format("%.2f", SSS);
     }
    
    public String calculatePhilhealth(){ // computes for Philhealth
        Philhealth = (Double.parseDouble(basicSalary) * 0.03)/2;
        return String.format("%.2f", Philhealth);
     }
     
    public String calculatePagibig(){ //computes for Pagibig          
         if(Double.parseDouble(basicSalary) <1000) {
            Pagibig = 0;}
         
         else if(Double.parseDouble(basicSalary) <=1500) {
            Pagibig = Double.parseDouble(basicSalary) *0.03;}
         
         else {
            Pagibig = Double.parseDouble(basicSalary)*0.04;}
              
       if(Pagibig >100) {
            Pagibig = 100;} //Pagibig contribution maximum amount is 100
       return String.format("%.2f", Pagibig);
    }
    
    public String calculateTaxable (){
        taxableIncome = grossPay - (SSS + Philhealth + Pagibig); //computes for taxable income
        return String.format("%.2f", taxableIncome);
    }   
    
    public String calculateWithholding(){ //computes for withholding tac
       if(mRate <= 20832) {
            withholdingTax = 0;}
         
         else if(mRate <33333) {
            withholdingTax = (taxableIncome-20833)*0.2;}
         
         else if(mRate <66667) {
            withholdingTax = ((taxableIncome-33333)*0.25)+2500;}
         
         else if(mRate <166667) {
            withholdingTax = ((taxableIncome-66667)*0.30)+10833;}
         
         else if(mRate <666667) {
            withholdingTax = ((taxableIncome-166667)*0.32)+40833.33;}
         
         else {
            withholdingTax = ((taxableIncome-666667)*0.35)+200833.33;} 
       
       return String.format("%.2f", withholdingTax);
       }
          
    public String calculateTotalDeductions(){
         totalDeductions = SSS + Philhealth + Pagibig + withholdingTax; //computes for the total deduction
         return String.format("%.2f", totalDeductions);
    }
 
    public void setSSS(double sss){
       SSS = sss;
   }
      public void setPhilhealth(double phil){
       Philhealth = phil;
   }
      public void setPagibig(double pagibig){
       Pagibig = pagibig;
   }
      public void setTotalDeductions(double td){
       totalDeductions = td;
   }
      public void setTaxable(double ti){
       taxableIncome = ti;
   }
      public void setWithholding(double wt){
       withholdingTax = wt;
   }
    }
 
public class Payroll extends Deduction{
    private String payDate;
    private double netPay;    
       
     public void setPayDate (String payD){
       payDate = payD;
    }
    
    public String getPayDate(){
       return payDate;
    }
    
    public void setNet(double nP){
        netPay = nP;
    }
    
    public String calculateNetPay(){
         netPay = grossPay - totalDeductions + totalAllowance;
         return String.format("%.2f", netPay);  
    }
    
    public void AddPayrollData() throws IOException{
          String CSVEmployee = "PayrollRecords.csv";
        try(CSVWriter Writer = new CSVWriter(new FileWriter(CSVEmployee, true))){
         String [] Column = new String[14]; 
         Column[0] = EmployeeID;
         Column[1] = payDate;
         Column[2] = payPeriod;
         Column[3] = basicSalary;
         Column[4] = riceSubsidy;
         Column[5] = phoneAllowance;
         Column[6] = clothingAllowance;
         Column[7] = String.valueOf(rate);
         Column[8] = String.valueOf(Twrkd);
         Column[9] = String.valueOf(Tot);
         Column[10] = String.valueOf(grossPay);
         Column[11] = String.valueOf(totalAllowance);
         Column[12] = String.valueOf(totalDeductions);         
         Column[13] = String.valueOf(netPay);
         Writer.writeNext(Column);
       }
    }

         public DefaultTableModel ViewPayrollRecords() throws FileNotFoundException, IOException, CsvValidationException {
        DefaultTableModel PayRecords;
         String CSVFilename = "PayrollRecords.csv";

        try (CSVReader reader = new CSVReader(new FileReader(CSVFilename))) {
            String[] information = reader.readNext();
            PayRecords = new DefaultTableModel(information, 0);

            String[] column;
            while ((column = reader.readNext()) != null) {
                if (column[0].equals(EmployeeID)) {
                    PayRecords.addRow(column);
                }
            }
        }

        return PayRecords;
    }
        

    public void DeletePayroll() throws FileNotFoundException, IOException, CsvValidationException {
        String CSVPayRecords = "PayrollRecords.csv";
        String temporaryfile = CSVPayRecords.replace(".csv", ".tmp");
        CSVReader reader = new CSVReader(new FileReader(CSVPayRecords));
        String[] Data;
        try(CSVWriter writer = new CSVWriter(new FileWriter(temporaryfile, true))){
            while((Data = reader.readNext()) != null){
                if(!Data[2].equals(payPeriod)){
                    writer.writeNext(Data);
                }
            }
            reader.close();
        } finally {
            new File(CSVPayRecords).delete(); //deletes original file
            new File(temporaryfile).renameTo(new File(CSVPayRecords)); //replaces file with temporary file
        }
    }
    
    public boolean checkPayRecord() throws FileNotFoundException, IOException, CsvValidationException{
            String csvFilename = "PayrollRecords.csv";
               try(CSVReader reader = new CSVReader(new FileReader(csvFilename))){
            String[] Information;
           while((Information = reader.readNext()) != null){
              if(Information[0].equals(EmployeeID)){
                return Information[2].equals(payPeriod);
              }
            }
        }
      return false;        
    }
}