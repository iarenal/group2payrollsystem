/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvValidationException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.table.DefaultTableModel;

public class SystemAdmin extends Employee {
   
    protected String password, access;
  
    public DefaultTableModel viewAllAccounts () throws IOException, CsvValidationException {
        String CSVAccounts = "Accounts.csv";
        DefaultTableModel Information;
        try(CSVReader Reader = new CSVReader(new FileReader(CSVAccounts))){
            String[] Data = Reader.readNext();
            Information = new DefaultTableModel(Data,0);
            String[] line;
            while((line = Reader.readNext()) != null){
                Information.addRow(line);
            }
        }
        return Information;
    }
    
    public DefaultTableModel viewAccount() throws FileNotFoundException, IOException, CsvValidationException {
        DefaultTableModel accounts;
        String CSVFilename = "Accounts.csv";

        try (CSVReader reader = new CSVReader(new FileReader(CSVFilename))) {
            String[] information = reader.readNext();
            accounts = new DefaultTableModel(information, 0);

            String[] column;
            while ((column = reader.readNext()) != null) {
                if (column[0].equals(email)) {
                    accounts.addRow(column);
                }
            }
        }

        return accounts;
    }
   
    public void AddNewAccount() throws IOException{
        String CSVAccount = "Accounts.csv";
        try(CSVWriter Writer = new CSVWriter(new FileWriter(CSVAccount, true))){
         String [] Column = new String[3];
         password = "M0t0R_ph-" + EmployeeID;
         email = lastName + EmployeeID + "@MotorPH.com";
         Column[0] = email;
         Column[1] = password;
         Column[2] = access;
         Writer.writeNext(Column); 
        }        
    }
     
    public void getData()throws IOException, CsvValidationException{
        String CSVFilename = "Accounts.csv";
        try(CSVReader Reader = new CSVReader(new FileReader(CSVFilename))){
            String[] Details;
            while((Details = Reader.readNext()) != null){
                if (Details[0].equals(email)){
                     email = Details[0];
                     password = Details[1];
                     access = Details[2];
                }
            }
        }
    }
    
    public void EditAccount() throws FileNotFoundException, IOException, CsvValidationException{
        String CSVFilename = "Accounts.csv";
        String temporaryfile = CSVFilename.replace(".csv", ".tmp"); 
        CSVReader Reader = new CSVReader (new FileReader(CSVFilename)); 
        String[] Column;
        try(CSVWriter Writer = new CSVWriter(new FileWriter(temporaryfile, true))) {
            while((Column = Reader.readNext()) != null){
                if (Column[0].equals(email)){
                    Column[0] = email;
                    Column[1] = password;
                    Column[2] = access;
                }
                Writer.writeNext(Column); 
            }
            Reader.close();
        }
        new File(CSVFilename).delete();
        new File(temporaryfile).renameTo(new File(CSVFilename));
        }
    
    public void Deactivate() throws FileNotFoundException, IOException, CsvValidationException {
        String CSVEmployee = "Accounts.csv";
        String temporaryfile = CSVEmployee.replace(".csv", ".tmp");
        CSVReader reader = new CSVReader(new FileReader(CSVEmployee));
        String[] Data;
        try(CSVWriter writer = new CSVWriter(new FileWriter(temporaryfile, true))){
            while((Data = reader.readNext()) != null){
                if(!Data[0].equals(email)){
                    writer.writeNext(Data);
                }
            }
            reader.close();
        } finally {
            new File(CSVEmployee).delete();
            new File(temporaryfile).renameTo(new File(CSVEmployee)); 
        }
    }
    
    public String getPassword(){
          return password;
    } 
    public void setPassword(char[] p){
        password = new String(p);
    }
    public String getAccess(){
          return access;
    }    
    public void setAccess(String a){
        access = a;
    }

    public boolean checkexisting() throws FileNotFoundException, IOException, CsvValidationException {
        String csvFilename = "Accounts.csv";
        try (CSVReader reader = new CSVReader(new FileReader(csvFilename))) {
            String[] account;
            while ((account = reader.readNext()) != null) {
                if (account[0].equals(email)) {
                    return true; 
                }
            }
        }

        return false;
    }

public class User extends SystemAdmin{
    
       
    public boolean EmployeeLogin() throws FileNotFoundException, IOException, CsvValidationException {
        String csvFilename = "Accounts.csv";
        try(CSVReader reader = new CSVReader(new FileReader(csvFilename))){
            String[] account;
           
           while((account = reader.readNext()) != null){
              if(account[0].equals(email)){
                return account[1].equals(password);
              }
            }
        }
      return false;
    }
    
    public boolean checkAccess() throws FileNotFoundException, IOException, CsvValidationException {
        String csvFilename = "Accounts.csv";
        try(CSVReader reader = new CSVReader(new FileReader(csvFilename))){
            String[] account;           
           while((account = reader.readNext()) != null){
              if(account[0].equals(email)){
                return account[2].equals(access);
              }
            }
        }
      return false;
    }
    }
}