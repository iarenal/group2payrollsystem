/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package Class;
import Frames.Login;
import Frames.SAmain;
import java.text.ParseException;

public class MyPortal {

    public static void main(String[] args) throws ParseException {
        Login Log = new Login();
       Log.show(); 
       SAmain sa = new SAmain();
       //sa.show();
    }
}
