/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvValidationException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.table.DefaultTableModel;

   public class Request extends Timesheet{
   
   protected String status, requestID;
    
    public String getrequestID(String filename) throws IOException, CsvValidationException {
        int rowCount = 0;
        try (CSVReader reader = new CSVReader(new FileReader(filename))) {
            while (reader.readNext() != null) {
                rowCount++;
            }
        }
        return String.valueOf(rowCount);
    }    
    
    public void setreqID(String rID){
        requestID = rID;
    }
    public String getreqID(){
        return requestID;
    }
    public String getStatus(){
        return status;
    }
    
    public void setStatus(String s){
        status = s;
    }
    
    public DefaultTableModel viewRequest(String CSVRequesttype) throws FileNotFoundException, IOException, CsvValidationException {
        DefaultTableModel Request;
        try (CSVReader reader = new CSVReader(new FileReader(CSVRequesttype))) {
            String[] information = reader.readNext();
            Request = new DefaultTableModel(information, 0);
            String[] column;
            while ((column = reader.readNext()) != null) {
                if (column[1].equals(EmployeeID)||column[2].equals(date)) {
                    Request.addRow(column);
                }
            }
        }
        return Request;
    }  
    
    public DefaultTableModel viewallRequest(String CSVRequesttype) throws FileNotFoundException, IOException, CsvValidationException {
        DefaultTableModel Request;
        try (CSVReader reader = new CSVReader(new FileReader(CSVRequesttype))) {
            String[] information = reader.readNext();
            Request = new DefaultTableModel(information, 0);
            String[] column;
            while ((column = reader.readNext()) != null) {
                if (column[6].equals(status)) {
                    Request.addRow(column);
                }
            }
        }
        return Request;
    }
    
       public class Leave extends Request{
        private String typeofLeave, leavedate, numofDays;
                private int TotalLeave, overalldays;
        
        public void settypeofLeave(String tL){
           typeofLeave = tL;
        }
        public String gettypeofLeave(){
           return typeofLeave;
        }
        public void setLeaveDate(String ld){
          leavedate = ld;
        }
        public String getLeaveDate(){
           return leavedate;
        }
        public void setnumberofdays(String NoD){
          numofDays = NoD;
        }
        public String getnumberofdays(){
          return numofDays;
        }
        public void setTotalLeave(int tl){
            TotalLeave = tl;
        }
        public String getTotalLeave(){
          return String.valueOf(TotalLeave);
        }
        
        public DefaultTableModel viewRequest() throws FileNotFoundException, IOException, CsvValidationException {
        DefaultTableModel Request;
        String CSVRequesttype = "Leave.csv";
        try (CSVReader reader = new CSVReader(new FileReader(CSVRequesttype))) {
            String[] information = reader.readNext();
            Request = new DefaultTableModel(information, 0);
            String[] column;
            while ((column = reader.readNext()) != null) {
                if (column[1].equals(EmployeeID)&&(column[3].equals(typeofLeave))) {
                    Request.addRow(column);
                }
            }
        }
        return Request;
    }
                
        public void submitRequest() throws IOException{
            String CSVLeave = "Leave.csv";
            try(CSVWriter Writer = new CSVWriter(new FileWriter(CSVLeave, true))){
            String [] Column = new String[7]; 
            Column[0] = requestID;
            Column[1] = EmployeeID;
            Column[2] = date;
            Column[3] = typeofLeave;
            Column[4] = leavedate;
            Column[5] = numofDays;
            Column[6] = "Pending";
            Writer.writeNext(Column);
            }    
        }
        
    public int getTALeavedays () throws IOException, CsvValidationException{
        String CSVEmployee = "Leave.csv";
        try(CSVReader Reader = new CSVReader(new FileReader(CSVEmployee))){
            String[] Column;
            while((Column = Reader.readNext()) != null){
                if (Column[1].equals(EmployeeID)&Column[3].equals(typeofLeave)&Column[6].equals("Approved")){
                    TotalLeave += Integer.parseInt(Column[5]);
                }
            }
        }
        return TotalLeave;
     }
     public int getoveralldays() {
        if (typeofLeave.equals("Emergency") || typeofLeave.equals("Sick")) {
             overalldays = 5;
            }
        else if (typeofLeave.equals("Vacation")) {
             overalldays = 10;
            }
        return overalldays;
    }
     public void changeStatus() throws FileNotFoundException, IOException, CsvValidationException{
        String CSVRequest = "Leave.csv";
        String temporaryfile = CSVRequest.replace(".csv", ".tmp"); 
        CSVReader Reader = new CSVReader (new FileReader(CSVRequest)); 
        String[] Column;
        try(CSVWriter Writer = new CSVWriter(new FileWriter(temporaryfile, true))) {
            while((Column = Reader.readNext()) != null){
                
                if (Column[0].equals(requestID)){
                   Column[0] = requestID;
                   Column[1] = EmployeeID;
                   Column[2] = date;
                   Column[3] = typeofLeave;
                   Column[4] = leavedate;
                   Column[5] = numofDays;
                   Column[6] = status;                   
                }
                Writer.writeNext(Column); 
            }
            Reader.close();
        }
        new File(CSVRequest).delete();
        new File(temporaryfile).renameTo(new File(CSVRequest));
    }
 }
          
    public class Overtime extends Request{
        private String OvertimeDate, numOfHrs;
        private int totalOThrs;
        
        public void setOvertimeDate(String otD){
           OvertimeDate = otD;
        }
        
        public String getovertimeDate(){
           return OvertimeDate;
        }
    
        public void setnumofOT(String OTh){
           numOfHrs = OTh;
        }
        public String getnumofOT(){
           return numOfHrs;
        }
        public String gettotalOThrs(){
           return numOfHrs;
        }
        public void submitRequest() throws IOException{
            String CSVOvertime = "Overtime.csv";
            try(CSVWriter Writer = new CSVWriter(new FileWriter(CSVOvertime, true))){
            String [] Column = new String[7]; 
            Column[0] = requestID;
            Column[1] = EmployeeID;
            Column[2] = date;
            Column[3] = payPeriod;
            Column[4] = OvertimeDate;
            Column[5] = numOfHrs;
            Column[6] = "Pending";
            Writer.writeNext(Column);
            }
        }
        
        public DefaultTableModel viewRequest() throws FileNotFoundException, IOException, CsvValidationException {
        DefaultTableModel Request;
        String CSVRequesttype = "Overtime.csv";
        try (CSVReader reader = new CSVReader(new FileReader(CSVRequesttype))) {
            String[] information = reader.readNext();
            Request = new DefaultTableModel(information, 0);
            String[] column;
            while ((column = reader.readNext()) != null) {
                if (column[1].equals(EmployeeID)&&column[3].equals(payPeriod)) {
                    Request.addRow(column);
                    }
                }
            }
        return Request;
    }
        public int getTaOThrs () throws IOException, CsvValidationException{
        String CSVEmployee = "Overtime.csv";
        try(CSVReader Reader = new CSVReader(new FileReader(CSVEmployee))){
            String[] Column;
            while((Column = Reader.readNext()) != null){
                if (Column[1].equals(EmployeeID)&Column[3].equals(payPeriod)&Column[6].equals("Approved")){
                    totalOThrs += Integer.parseInt(Column[5]);
                }
            }
        }
        return totalOThrs;
     }
             public void changeStatus() throws FileNotFoundException, IOException, CsvValidationException{
        String CSVRequest = "Overtime.csv";
        String temporaryfile = CSVRequest.replace(".csv", ".tmp"); 
        CSVReader Reader = new CSVReader (new FileReader(CSVRequest)); 
        String[] Column;
        try(CSVWriter Writer = new CSVWriter(new FileWriter(temporaryfile, true))) {
            while((Column = Reader.readNext()) != null){
                if (Column[0].equals(requestID)){
                   Column[0] = requestID;
                   Column[1] = EmployeeID;
                   Column[2] = date;
                   Column[3] = payPeriod;
                   Column[4] = OvertimeDate;
                   Column[5] = numOfHrs;
                   Column[6] = status;                   
                }
                Writer.writeNext(Column); 
            }
            Reader.close();
        }
        new File(CSVRequest).delete();
        new File(temporaryfile).renameTo(new File(CSVRequest));
    }
    }
   }
    


