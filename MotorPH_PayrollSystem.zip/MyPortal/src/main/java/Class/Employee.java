/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import java.io.FileReader;
import java.io.IOException;

public class Employee {

    protected String EmployeeID, firstName, lastName, fullName, birthday, address, email, phoneNumber;
        
    public String getEmployeeID(){
       return EmployeeID;
   }
    public String getlastname(){
       return lastName;
   }
    
    public String getfirstname(){
       return firstName;
   }
    
    public String getName(){
        return fullName;
    }
     
    public String getBirthday(){
       return birthday;
   }
    
    public String getAddress(){
       return address;
   }
    
    public String getPhoneNumber(){
       return phoneNumber;
   }
    public String getemail(){
        email = lastName + EmployeeID + "@MotorPH.com";
        return email;
    }
            
 
    //setter for variables
    public void setEmployeeID(String eID){
       EmployeeID = eID;
   }
      
    public void setlastname(String ln){
       lastName = ln;
   }
    
    public void setfirstname(String fn){
       firstName = fn;
   } 
    
    public void setName(String name){
        fullName = name;
    }
    public void setBirthday(String b){
       birthday = b;
   }
    
    public void setAddress(String add){
       address = add;
   }
    
    public void setPhoneNumber(String pn){
       phoneNumber = pn;
   }
    
      public void setemail(String e){
        email = e;
    }

    public void EmployeeBasicInfo()throws IOException, CsvValidationException{
        String CSVEmployee = "OfficialEmployeeData.csv";
        try(CSVReader Reader = new CSVReader(new FileReader(CSVEmployee))){
            String[] Column;
            while((Column = Reader.readNext()) != null){
                if (Column[6].equals(email)| Column[0].equals(EmployeeID) | Column[1].equals(lastName)){
                    EmployeeID = Column[0];
                    lastName = Column[1];
                    firstName = Column[2];
                    fullName = Column[1] + ", " + Column[2];
                    email = Column[6];
                }
            }
        }
    }
}


