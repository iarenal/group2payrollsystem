/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvValidationException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.table.DefaultTableModel;


public class HR extends Finance{ 
   private String position, status, supervisor, datehired;
   
    public String getStatus(){
       return status;
   }
    
    public String getPosition(){
       return position;
   }
    public String getSupervisor(){
       return supervisor;
   }
    public String getDatehired(){
       return datehired;
   }
    
    public void setStatus(String s){
       status = s;
   }
    
    public void setPosition(String p){
       position = p;
   }
        
    public void setSupervisor(String s){
       supervisor = s;
   }
    public void setDatehired(String dh){
       datehired = dh;
   }
    
      public void AddEmployee() throws IOException{
           String CSVEmployee = "OfficialEmployeeData.csv";
        try(CSVWriter Writer = new CSVWriter(new FileWriter(CSVEmployee, true))){
         String [] Column = new String[11]; 
         Column[0] = EmployeeID;
         Column[1] = lastName;
         Column[2] = firstName;
         Column[3] = birthday;
         Column[4] = address;
         Column[5] = phoneNumber;
         Column[6] = email;
         Column[7] = status;
         Column[8] = position;
         Column[9] = supervisor;
         Column[10] = datehired;
         Writer.writeNext(Column);
    }
    }
      
     public void AddPayrollData() throws IOException{
          String CSVEmployee = "PayrollData.csv";
        try(CSVWriter Writer = new CSVWriter(new FileWriter(CSVEmployee, true))){
         String [] Column = new String[12]; 
         Column[0] = EmployeeID;
         Column[1] = lastName;
         Column[2] = position;
         Column[3] = status;
         Column[4] = SSSno;
         Column[5] = Philhealthno;
         Column[6] = TIN;
         Column[7] = Pagibigno;
         Column[8] = riceSubsidy;
         Column[9] = phoneAllowance;
         Column[10] = clothingAllowance;
         Column[11] = basicSalary;
         Writer.writeNext(Column);
    }
    }
              
    public void DeleteEmployee() throws FileNotFoundException, IOException, CsvValidationException {
        String CSVEmployee = "OfficialEmployeeData.csv";
        String temporaryfile = CSVEmployee.replace(".csv", ".tmp");
        CSVReader reader = new CSVReader(new FileReader(CSVEmployee));
        String[] Data;
        try(CSVWriter writer = new CSVWriter(new FileWriter(temporaryfile, true))){
            while((Data = reader.readNext()) != null){
                if(!Data[0].equals(EmployeeID)){
                    writer.writeNext(Data);
                }
            }
            reader.close();
        } finally {
            new File(CSVEmployee).delete(); //deletes original file
            new File(temporaryfile).renameTo(new File(CSVEmployee)); //replaces file with temporary file
        }
    }
    
        public void DeletePayrollData() throws FileNotFoundException, IOException, CsvValidationException {
        String CSVEmployee = "PayrollData.csv";
        String temporaryfile = CSVEmployee.replace(".csv", ".tmp");
        CSVReader reader = new CSVReader(new FileReader(CSVEmployee));
        String[] Data;
        try(CSVWriter writer = new CSVWriter(new FileWriter(temporaryfile, true))){
            while((Data = reader.readNext()) != null){
                if(!Data[0].equals(EmployeeID)){
                    writer.writeNext(Data);
                }
            }
            reader.close();
        } finally {
            new File(CSVEmployee).delete(); //deletes original file
            new File(temporaryfile).renameTo(new File(CSVEmployee)); //replaces file with temporary file
        }
    }
           
    public void EditInfo() throws FileNotFoundException, IOException, CsvValidationException{
        String CSVEmployee = "OfficialEmployeeData.csv";
        String temporaryfile = CSVEmployee.replace(".csv", ".tmp"); 
        CSVReader Reader = new CSVReader (new FileReader(CSVEmployee)); 
        String[] Column;
        try(CSVWriter Writer = new CSVWriter(new FileWriter(temporaryfile, true))) {
            while((Column = Reader.readNext()) != null){
                
                if (Column[0].equals(EmployeeID)){
                    Column[1] = lastName;
                    Column[2] = firstName;
                    Column[3] = birthday;
                    Column[4] = address;
                    Column[5] = phoneNumber;
                    email = Column[1] + Column[0] +"@MotorPH.com";
                    Column[6] = email;
                    Column[7] = status;
                    Column[8] = position;
                    Column[9] = supervisor;
                    Column[10] = datehired;
                }
                Writer.writeNext(Column); 
            }
            Reader.close();
        }
        new File(CSVEmployee).delete();
        new File(temporaryfile).renameTo(new File(CSVEmployee));
}
    
        public void EditPayrollData() throws FileNotFoundException, IOException, CsvValidationException{
        String CSVEmployee = "PayrollData.csv";
        String temporaryfile = CSVEmployee.replace(".csv", ".tmp"); 
        CSVReader Reader = new CSVReader (new FileReader(CSVEmployee)); 
        String[] Column;
        try(CSVWriter Writer = new CSVWriter(new FileWriter(temporaryfile, true))) {
            while((Column = Reader.readNext()) != null){
                
                if (Column[0].equals(EmployeeID)){
                    Column[0] = EmployeeID;
                    Column[1] = lastName;
                    Column[2] = position;
                    Column[3] = status;
                    Column[4] = SSSno;
                    Column[5] = Philhealthno;
                    Column[6] = TIN;
                    Column[7] = Pagibigno;
                    Column[8] = riceSubsidy;
                    Column[9] = phoneAllowance;
                    Column[10] = clothingAllowance;
                    Column[11] = basicSalary;
                }
                Writer.writeNext(Column); 
            }
            Reader.close();
        }
        new File(CSVEmployee).delete();
        new File(temporaryfile).renameTo(new File(CSVEmployee));
}
                   
    public DefaultTableModel ViewEmployeeList () throws IOException, CsvValidationException {
        String CSVEmployee = "OfficialEmployeeData.csv";
        DefaultTableModel Information;
        try(CSVReader Reader = new CSVReader(new FileReader(CSVEmployee))){
            String[] Data = Reader.readNext();
            Information = new DefaultTableModel(Data,0);
            String[] line;
            while((line = Reader.readNext()) != null){
                Information.addRow(line);
            }
        }
        return Information;
    }
        public void SearchHR()throws IOException, CsvValidationException{
        String CSVFilename = "OfficialEmployeeData.csv";
        try(CSVReader Reader = new CSVReader(new FileReader(CSVFilename))){
            String[] Details;
            while((Details = Reader.readNext()) != null){
                if (Details[0].equals(EmployeeID)|Details[1].equals(lastName)|Details[6].equals(email)){
                     EmployeeID = Details[0];
                     lastName = Details[1];
                     firstName = Details[2];
                     birthday = Details[3];           
                     address  = Details[4];
                     phoneNumber = Details[5];
                     email = Details[6];
                     status = Details[7];
                     position = Details[8];
                     supervisor = Details[9];
                     datehired = Details[10];
                }
            }
        }
    }
    public DefaultTableModel searchtblemployees() throws FileNotFoundException, IOException, CsvValidationException {
        DefaultTableModel EmployeeData;
         String CSVFilename = "OfficialEmployeeData.csv";
        try (CSVReader reader = new CSVReader(new FileReader(CSVFilename))) {
            String[] information = reader.readNext();
            EmployeeData = new DefaultTableModel(information, 0);

            String[] column;
            while ((column = reader.readNext()) != null) {
                if (column[0].equals(EmployeeID)|column[1].equals(lastName)|column[2].equals(firstName)|
                    column[7].equals(status)|column[8].equals(position)|column[9].equals(supervisor)|
                    column[10].equals(datehired)) {
                    EmployeeData.addRow(column);
                }
            }
        }

        return EmployeeData;
    }
}

  
